package sungshin.base.hazelcast.cache.expiry;

import javax.cache.configuration.Factory;
import javax.cache.expiry.Duration;
import javax.cache.expiry.ExpiryPolicy;

@SuppressWarnings("serial")
public class ExpiryPolicyFactory implements Factory<ExpiryPolicy> {
    @Override
    public ExpiryPolicy create() {
        return new ExpiryPolicy() {
            @Override public Duration getExpiryForCreation() {
                return Duration.ETERNAL;
            }

            @Override public Duration getExpiryForAccess() {
                return Duration.ETERNAL;
            }

            @Override public Duration getExpiryForUpdate() {
                return Duration.ETERNAL;
            }
        };
    }
}