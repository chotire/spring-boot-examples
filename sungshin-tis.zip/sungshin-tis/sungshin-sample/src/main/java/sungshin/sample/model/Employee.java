package sungshin.sample.model;

import java.io.Serializable;
import java.util.Date;

import com.nexacro.spring.data.DataSetSavedDataAccessor;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import sungshin.base.domain.NexacroDomain;

/**
 * Employee
 * @author 김용식
 * @version 1.0
 * <pre>
 * 수정일                수정자         수정내용
 * ---------------------------------------------------------------------
 * 2017.01.23 김용식          최초작성
 * </pre>
 */
@SuppressWarnings("serial")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Employee extends NexacroDomain implements DataSetSavedDataAccessor<Employee>, Serializable {
    private String id;
    private String name;
    private Date hireDate;
    private Integer salary;
    private Boolean married;

    /**
     * DataSet의 SavedData (원본데이터)의 경우 :A 옵션으로 데이터를 전송할 경우에만 저장된다.
     */
    private Employee savedData;

    @Override
    public Employee getData() {
        return savedData;
    }

    @Override
    public void setData(Employee savedData) {
        this.savedData = savedData;
    }
}