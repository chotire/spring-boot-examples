package sungshin.sample.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import sungshin.base.mybatis.type.CamelCaseMap;
import sungshin.sample.model.EmpAcdmcr;
import sungshin.sample.model.EmpAddr;
import sungshin.sample.model.EmpCareer;
import sungshin.sample.model.Employee;

/**
 * EmployeeMapper
 * @author 김용식
 * @version 1.0
 * <pre>
 * 수정일                수정자         수정내용
 * ---------------------------------------------------------------------
 * 2017.01.23 김용식          최초작성
 * </pre>
 */
@Repository
public interface EmployeeMapper {
    List<CamelCaseMap> findEmployees(Employee employee);
    List<CamelCaseMap> findEmployeeByPk(String id);

    void insertEmployee(Employee employee);
    void updateEmployee(Employee employee);
    void deleteEmployee(Employee employee);

    List<CamelCaseMap> findEmpCareers(EmpCareer empCareer);
    List<CamelCaseMap> findEmpAcdmcrs(EmpAcdmcr empAcdmcr);

    void insertEmpAcdmcr(EmpAcdmcr empAcdmcr);
    void updateEmpAcdmcr(EmpAcdmcr empAcdmcr);
    void deleteEmpAcdmcr(EmpAcdmcr empAcdmcr);

    void insertEmpCareer(EmpCareer empCareer);
    void updateEmpCareer(EmpCareer empCareer);
    void deleteEmpCareer(EmpCareer empCareer);

    List<CamelCaseMap> findEmpAddr(EmpAddr empAddr);

    void insertEmpAddr(EmpAddr empAddr);
    void updateEmpAddr(EmpAddr empAddr);
    void deleteEmpAddr(EmpAddr empAddr);
}