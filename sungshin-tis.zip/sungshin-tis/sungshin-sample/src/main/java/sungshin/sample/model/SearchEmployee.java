package sungshin.sample.model;

import lombok.Data;
import sungshin.base.domain.NexacroDomain;

/**
 * SearchEmployee
 * @author 김용식
 * @version 1.0
 * <pre>
 * 수정일                수정자         수정내용
 * ---------------------------------------------------------------------
 * 2017.01.23 김용식          최초작성
 * </pre>
 */
@Data
public class SearchEmployee extends NexacroDomain {
    private String id;
    private String name;
}