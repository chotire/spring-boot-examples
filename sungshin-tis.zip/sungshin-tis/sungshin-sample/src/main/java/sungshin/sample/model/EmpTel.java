package sungshin.sample.model;

import com.nexacro.spring.data.DataSetSavedDataAccessor;

import lombok.Data;
import sungshin.base.domain.NexacroDomain;

/**
 * EmpTel
 * @author 김용식
 * @version 1.0
 * <pre>
 * 수정일                수정자         수정내용
 * ---------------------------------------------------------------------
 * 2017.01.23 김용식          최초작성
 * </pre>
 */
@Data
public class EmpTel extends NexacroDomain implements DataSetSavedDataAccessor<EmpTel> {
    private String id;
    private String tellTyCd;
    private String zipNo;
    private String addr1;
    private String addr2;
    private String addr1Eng;
    private String addr2Eng;

    /**
     * DataSet의 SavedData (원본데이터)의 경우 :A 옵션으로 데이터를 전송할 경우에만 저장된다.
     */
    private EmpTel savedData;

    @Override
    public EmpTel getData() {
        return savedData;
    }

    @Override
    public void setData(EmpTel savedData) {
        this.savedData = savedData;
    }
}