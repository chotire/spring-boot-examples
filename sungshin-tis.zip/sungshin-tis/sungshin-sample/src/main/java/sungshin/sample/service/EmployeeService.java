package sungshin.sample.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nexacro.xapi.data.DataSet;

import sungshin.base.mybatis.type.CamelCaseMap;
import sungshin.base.service.BaseService;
import sungshin.sample.model.EmpAcdmcr;
import sungshin.sample.model.EmpAddr;
import sungshin.sample.model.EmpCareer;
import sungshin.sample.model.Employee;
import sungshin.sample.repository.EmployeeMapper;

/**
 * service interface는 생성하지 않는다.<br>
 * BaseService를 상속 받는다. (트랜잭션 처리)<br>
 * @author 김용식
 * @version 1.0
 * <pre>
 * 수정일                수정자         수정내용
 * ---------------------------------------------------------------------
 * 2017.01.23 김용식          최초작성
 * </pre>
 */
@Service
public class EmployeeService extends BaseService{
    @Autowired
    private EmployeeMapper employeeMapper;

    /**
     * 사원정보리스트를 조회한다.
     * @param employee 검색조건
     * @return 사원정보리스트
     */
    public List<CamelCaseMap> findEmployees(Employee employee) {
        return employeeMapper.findEmployees(employee);
    }

    /**
     * 사원정보를 조회한다.
     * @param id 검색조건
     * @return 사원정보
     */
    public List<CamelCaseMap> findEmployeeByPk(String id) {
        return employeeMapper.findEmployeeByPk(id);
    }

    /**
     * 사원정보리스트를 저장 한다.
     * @param employees 저장할사원정보리스트
     */
    public void saveEmployees(List<Employee> employees) {
        for(Employee employee : employees){
            switch (employee.getRowType()) {
                case DataSet.ROW_TYPE_INSERTED :
                    employeeMapper.insertEmployee(employee);
                    break;
                case DataSet.ROW_TYPE_UPDATED :
                    employeeMapper.updateEmployee(employee);
                    break;
                case DataSet.ROW_TYPE_DELETED :
                    employeeMapper.deleteEmployee(employee);
                    break;
                default :
                    break;
            }
        }
    }

    /**
     * 경력정보리스트를 조회한다.
     * @param empAcdmcr 검색조건
     * @return 경력정보리스트
     */
    public List<?> findEmpAcdmcrs(EmpAcdmcr empAcdmcr) {
        return employeeMapper.findEmpAcdmcrs(empAcdmcr);
    }

    /**
     * 경력정보리스트를 저장 한다.
     * @param empAcdmcrs 저장할경력정보리스트
     */
    public void saveEmpAcdmcrs(List<EmpAcdmcr> empAcdmcrs) {
        for(EmpAcdmcr empAcdmcr : empAcdmcrs){
            switch (empAcdmcr.getRowType()) {
                case DataSet.ROW_TYPE_INSERTED :
                    employeeMapper.insertEmpAcdmcr(empAcdmcr);
                    break;
                case DataSet.ROW_TYPE_UPDATED :
                    employeeMapper.updateEmpAcdmcr(empAcdmcr);
                    break;
                case DataSet.ROW_TYPE_DELETED :
                    employeeMapper.deleteEmpAcdmcr(empAcdmcr);
                    break;
                default :
                    break;
            }
        }
    }

    /**
     * 학력정보리스트를 조회한다.
     * @param empCareer 검색조건
     * @return 학력정보리스트
     */
    public List<?> findEmpCareers(EmpCareer empCareer) {
        return employeeMapper.findEmpCareers(empCareer);
    }

    /**
     * 학력정보리스트를 저장 한다.
     * @param empCareers 저장할학력정보리스트
     */
    public void saveEmpCareers(List<EmpCareer> empCareers) {
        for(EmpCareer empCareer : empCareers){
            switch (empCareer.getRowType()) {
                case DataSet.ROW_TYPE_INSERTED :
                    employeeMapper.insertEmpCareer(empCareer);
                    break;
                case DataSet.ROW_TYPE_UPDATED :
                    employeeMapper.updateEmpCareer(empCareer);
                    break;
                case DataSet.ROW_TYPE_DELETED :
                    employeeMapper.deleteEmpCareer(empCareer);
                    break;
                default :
                    break;
            }
        }
    }

    /**
     * 주소정보를 조회한다.
     * @param empAddr 검색조건
     * @return 주소정보
     */
    public List<CamelCaseMap> findEmpAddr(EmpAddr empAddr) {
        return employeeMapper.findEmpAddr(empAddr);
    }

    /**
     * 주소정보를 저장 한다.
     * @param empAddrs 저장할주소정보리스트
     */
    public void saveEmpAddr(List<EmpAddr> empAddrs) {
        for(EmpAddr empAddr : empAddrs){
            switch (empAddr.getRowType()) {
                case DataSet.ROW_TYPE_INSERTED :
                    employeeMapper.insertEmpAddr(empAddr);
                    break;
                case DataSet.ROW_TYPE_UPDATED :
                    employeeMapper.updateEmpAddr(empAddr);
                    break;
                case DataSet.ROW_TYPE_DELETED :
                    employeeMapper.deleteEmpAddr(empAddr);
                    break;
                default :
                    break;
            }
        }
    }


}
