package sungshin.sample.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nexacro.spring.annotation.ParamDataSet;
import com.nexacro.spring.data.NexacroResult;

import sungshin.sample.model.EmpAcdmcr;
import sungshin.sample.model.EmpAddr;
import sungshin.sample.model.EmpCareer;
import sungshin.sample.model.Employee;
import sungshin.sample.service.EmployeeService;

/**
 * 사원관리에 대한 Client의 요청을 받아 처리한다.<br>
 * @author 김용식
 * @version 1.0
 * <pre>
 * 수정일                수정자         수정내용
 * ---------------------------------------------------------------------
 * 2017.01.23 김용식          최초작성
 * </pre>
 */
@Controller
@RequestMapping(value = "/sample")
public class EmployeeController {
    @Autowired
    protected EmployeeService employeeService;

    /**
     * 사원정보리스트를 조회한다.
     * @param searchEmployee 검색조건
     * @return 사원정보리스트
     */
    @GetMapping("/employees")
    public NexacroResult findEmployees(@ParamDataSet(name = "searchEmployee") Employee employee) {
        return new NexacroResult("employees", employeeService.findEmployees(employee));
    }

    /**
     * 사원정보를 조회한다.
     * @param searchEmployee 검색조건
     * @return 사원정보
     * URI parameter 2개로 제한
     * 사용여부 ??
     */
    @GetMapping("/employees/{id}/")
    public NexacroResult findEmployee(@PathVariable String id) {
        return new NexacroResult("employee", employeeService.findEmployeeByPk(id));
    }

    /**
     * 사원정보리스트를 저장한다.
     * @param saveEmployees 저장할사원정보리스트
     * @return null
     */
    @PostMapping("/employees")
    public NexacroResult saveEmployees(@ParamDataSet(name = "saveEmployees") List<Employee> saveEmployees) {
        employeeService.saveEmployees(saveEmployees);
        return NexacroResult.EMPTY;
    }

    /**
     * 경력정보리스트를 조회한다.
     * @param searchEmpAcdmcr 검색조건
     * @return 경력정보리스트
     */
    @GetMapping("/empAcdmcrs")
    public NexacroResult findEmpAcdmcrs(@ParamDataSet(name = "searchEmpAcdmcr") EmpAcdmcr empAcdmcr) {
        return new NexacroResult("empAcdmcrs", employeeService.findEmpAcdmcrs(empAcdmcr));
    }

    /**
     * 경력정보리스트를 저장한다.
     * @param saveEmpAcdmcrs 저장할경력정보리스트
     * @return null
     */
    @PostMapping("/empAcdmcrs")
    public NexacroResult saveEmpAcdmcrs(@ParamDataSet(name = "saveEmpAcdmcrs") List<EmpAcdmcr> empAcdmcrs) {
        employeeService.saveEmpAcdmcrs(empAcdmcrs);
        return NexacroResult.EMPTY;
    }

    /**
     * 학력정보리스트를 조회한다.
     * @param searchEmpCareer 검색조건
     * @return 학력정보리스트
     */
    @GetMapping("/empCareers")
    public NexacroResult findEmpCareers(@ParamDataSet(name = "searchEmpCareer") EmpCareer empCareer) {
        return new NexacroResult("empCarrers", employeeService.findEmpCareers(empCareer));
    }

    /**
     * 학력정보리스트를 저장한다.
     * @param saveEmpCareers 저장할학력정보리스트
     * @return null
     */
    @PostMapping("/empCareers")
    public NexacroResult saveEmpCareers(@ParamDataSet(name = "saveEmpCareers") List<EmpCareer> empCareers) {
        employeeService.saveEmpCareers(empCareers);
        return NexacroResult.EMPTY;
    }

    /**
     * 주소정보를 조회한다.
     * @param searchEmpCareer 검색조건
     * @return 주소정보
     */
    @GetMapping("/empAddr")
    public NexacroResult findEmpAddr(@ParamDataSet(name = "searchEmpAddr") EmpAddr empAddr) {
        return new NexacroResult("empAddr", employeeService.findEmpAddr(empAddr));
    }

    /**
     * 주소정보를 저장한다.
     * @param saveEmpCareers 저장할주소정보리스트
     * @return null
     */
    @PostMapping("/empAddr")
    public NexacroResult saveEmpAddr(@ParamDataSet(name = "saveEmpAddr") List<EmpAddr> empAddrs) {
        employeeService.saveEmpAddr(empAddrs);
        return NexacroResult.EMPTY;
    }

}