package sungshin.cache;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import sungshin.sample.model.Employee;

@Slf4j
@CacheConfig(cacheNames = "code")
@Service
public class CacheService {
    private static Calendar calendar = Calendar.getInstance();
    private static final Map<String, Employee> DATA;

    static {
        DATA = new HashMap<String, Employee>();

        calendar.set(2010, 6, 19);
        DATA.put("it0324", new Employee("it0324", "조용상", calendar.getTime(), 3200, true, null));

        calendar.set(2013, 10, 6);
        DATA.put("it0325", new Employee("it0325", "홍길동", calendar.getTime(), 1200, false, null));

        calendar.set(2013, 5, 5);
        DATA.put("it0326", new Employee("it0326", "성춘향", calendar.getTime(), 5500, false, null));

        calendar.set(2016, 8, 9);
        DATA.put("it0327", new Employee("it0327", "이몽룡", calendar.getTime(), 3300, true, null));
    }

    @Cacheable
    public Employee findById(String id) {
        log.debug("[{}] has been cached.", id);
        return DATA.get(id);
    }

    @CacheEvict(key = "#employee.id")
    public void modify(Employee employee) {
        log.debug("[{}] has been removed from the cache.", employee.getId());
        DATA.put(employee.getId(), employee);
    }

    @CacheEvict
    public void remove(String id) {
        log.debug("[{}] has been removed from the cache.", id);
//        DATA.remove(id);
    }
}