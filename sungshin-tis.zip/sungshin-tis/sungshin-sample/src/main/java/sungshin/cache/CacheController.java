package sungshin.cache;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import sungshin.sample.model.Employee;

@RestController
@RequestMapping("/cache")
public class CacheController {
    @Autowired
    private CacheService cacheService;

    @GetMapping("/cacheable/{id}")
    public Employee findById(@PathVariable String id) {
        return cacheService.findById(id);
    }

    @GetMapping("/remove/{ids}")
    public void remove(@PathVariable String[] ids) {
        for (String id : ids) {
            cacheService.remove(id);
        }
    }

    @GetMapping("/modify/{id}")
    public void modify(Employee employee) {
        cacheService.modify(employee);
    }
}