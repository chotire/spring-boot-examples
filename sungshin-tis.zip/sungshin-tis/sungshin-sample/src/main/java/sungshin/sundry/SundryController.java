package sungshin.sundry;

import java.util.Locale;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value = "/sundry")
public class SundryController {
    @Autowired
    private MessageSource messageSource;

    @GetMapping("/session")
    @ResponseBody
    public String session(HttpSession session){
        session.setAttribute("name", "chotire");
        return session.getId();
    }

    @GetMapping("/i18n/{code:.+}")
    @ResponseBody
    public String i18n(@PathVariable String code) {
        Locale locale = LocaleContextHolder.getLocale();
        return messageSource.getMessage(code, null, locale);
    }
}