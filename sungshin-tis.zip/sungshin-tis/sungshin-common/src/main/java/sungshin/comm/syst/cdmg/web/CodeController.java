package sungshin.comm.syst.cdmg.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nexacro.spring.annotation.ParamDataSet;
import com.nexacro.spring.data.NexacroResult;

import lombok.extern.slf4j.Slf4j;
import sungshin.comm.syst.cdmg.model.Code;
import sungshin.comm.syst.cdmg.service.CodeService;

/**
 * 공통코드를 조회한다.<br>
 * @author 김용식
 * @version 1.0
 * <pre>
 * 수정일                수정자         수정내용
 * ---------------------------------------------------------------------
 * 2017.01.26 김용식          최초작성
 * </pre>
 */
@Slf4j
@Controller
@RequestMapping(value = "/comm/syst/cdmg")
public class CodeController {
    @Autowired
    protected CodeService codeService;

    /**
     * 공통코드정보를 조회한다.
     * @param searchCodes 검색조건
     * @return 공통코드리스트
     */
    @PostMapping("/codes")
    public NexacroResult findCodes(@ParamDataSet(name = "searchCodes") List<Code> Codes) {
        NexacroResult result = new NexacroResult();

        for(Code code : Codes){
            result.addDataSet(code.getOutDs(), codeService.findCodes(code));
        }

        log.debug("This is a debug message, nexacro result: {}", result);
        return result;
    }

    /**
     * 공통코드를 저장한다.
     * @param saveCodes 저장할공통코드리스트
     * @return null
     */
    @PutMapping("/codes")
    public NexacroResult saveCodes(@ParamDataSet(name = "saveCodes") List<Code> Codes) {
        codeService.saveCodes(Codes);
        return NexacroResult.EMPTY;
    }

}
