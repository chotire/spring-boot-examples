package sungshin.comm.syst.cdmg.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import sungshin.base.mybatis.type.CamelCaseMap;
import sungshin.comm.syst.cdmg.model.Code;

/**
 * @author 김용식
 * @version 1.0
 * <pre>
 * 수정일                수정자         수정내용
 * ---------------------------------------------------------------------
 * 2017.01.26 김용식          최초작성
 * </pre>
 */
@Repository
public interface CodeMapper {
    List<CamelCaseMap> findCodes(Code code);
    int insertCode(Code code);
    int updateCode(Code code);
    int deleteCode(Code code);
}