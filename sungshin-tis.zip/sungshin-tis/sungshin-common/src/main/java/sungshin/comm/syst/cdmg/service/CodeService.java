package sungshin.comm.syst.cdmg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nexacro.xapi.data.DataSet;

import sungshin.base.service.BaseService;
import sungshin.comm.syst.cdmg.model.Code;
import sungshin.comm.syst.cdmg.repository.CodeMapper;

/**
 * service interface는 생성하지 않는다.<br>
 * BaseService를 상속 받는다. (트랜잭션 처리)<br>
 * @author 김용식
 * @version 1.0
 * <pre>
 * 수정일                수정자         수정내용
 * ---------------------------------------------------------------------
 * 2017.01.26 김용식          최초작성
 * </pre>
 */
@Service
public class CodeService extends BaseService{
    @Autowired
    private CodeMapper codeMapper;

    /**
     * 공통코드정보를 조회한다.
     */
    /**
     * 공통코드정보를 조회한다.
     * @param code 검색조건
     * @return 공통코드리스트
     */
    public List<?> findCodes(Code code) {
        return codeMapper.findCodes(code);
    }

    /**
     * 공통코드리스트를 저장한다.
     * @param codes 저장할공통코드리스트
     */
    public void saveCodes(List<Code> codes) {
        for(Code code : codes){
            switch (code.getRowType()) {
                case DataSet.ROW_TYPE_INSERTED :
                    codeMapper.insertCode(code);
                    break;
                case DataSet.ROW_TYPE_UPDATED :
                    codeMapper.updateCode(code);
                    break;
                case DataSet.ROW_TYPE_DELETED :
                    codeMapper.deleteCode(code);
                    break;
                default :
                    break;
            }
        }
    }


}
