package sungshin.comm.syst.cdmg.model;

import org.springframework.jdbc.support.JdbcUtils;

import com.nexacro.spring.data.DataSetSavedDataAccessor;

import lombok.Data;
import sungshin.base.domain.NexacroDomain;

/**
 * Code
 * @author 김용식
 * @version 1.0
 * <pre>
 * 수정일                수정자         수정내용
 * ---------------------------------------------------------------------
 * 2017.01.26 김용식          최초작성
 * </pre>
 */
@Data
public class Code extends NexacroDomain implements DataSetSavedDataAccessor<Code> {
    private String codeId;
    private String codeVal;
    private String codeValNm;

    /**
     * DataSet의 SavedData (원본데이터)의 경우 :A 옵션으로 데이터를 전송할 경우에만 저장된다.
     */
    private Code savedData;

    @Override
    public Code getData() {
        return savedData;
    }

    @Override
    public void setData(Code savedData) {
        this.savedData = savedData;
    }

    public String getOutDs(){
        return JdbcUtils.convertUnderscoreNameToPropertyName(codeId) + "s";
    }
}