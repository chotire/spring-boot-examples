package sungshin;

import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.ResourcePatternResolver;

import sungshin.base.io.support.SpecificResourcePatternResolver;

/**
 * @author YongSang
 * @see http://roufid.com/load-multiple-configuration-files-different-directories-spring-boot
 */
@SpringBootApplication
public class Application extends SpringBootServletInitializer {
    @SuppressWarnings("serial")
    public static final Set<String> EXCLUDE_PROPERTY_SOURCES = new HashSet<String>() {{
        add("application.yml");
    }};

    @SuppressWarnings("serial")
    public static final Set<String> TOP_PRIORITY_PROPERTY_SOURCES = new HashSet<String>() {{
        add("sungshin-common.yml");
        add("actuator-common.yml");
    }};

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        try {
            buildApplication(application, "classpath:");
        } catch (IOException e) {
            throw new IllegalStateException("Failed to execute Application", e);
        }
        return application.sources(Application.class);
    }

    public static void main(String[] args) throws IOException {
        SpringApplicationBuilder application = new SpringApplicationBuilder(Application.class);
        buildApplication(application, "classpath*:");
        application.build().run(args);
    }

    private static void buildApplication(SpringApplicationBuilder application, String classpathUrlPrefix) throws IOException {
        List<String> propertyNames = findPropertySourceNames(classpathUrlPrefix);
        StringBuilder buildProperties = new StringBuilder();
        for (String propertyName : propertyNames) {
            buildProperties.append("classpath:/").append(propertyName).append(",");
        }
        buildProperties.setLength(buildProperties.length() - 1);
        application.properties("spring.config.location:" + buildProperties.toString());
    }

    private static List<String> findPropertySourceNames(String classpathUrlPrefix) throws IOException {
        ResourcePatternResolver resourceResolver = new SpecificResourcePatternResolver();
        Resource[] properties = resourceResolver.getResources(classpathUrlPrefix + "/*.yml");
        List<String> names = new CopyOnWriteArrayList<>();
        for (Resource property : properties) {
            if (!EXCLUDE_PROPERTY_SOURCES.contains(property.getFilename())) {
                names.add(property.getFilename());
            }
        }
        sortPropertySourceNames(names);
        return names;
    }

    private static void sortPropertySourceNames(List<String> names) {
        for (String name : names) {
            if (TOP_PRIORITY_PROPERTY_SOURCES.contains(name)) {
                names.remove(name);
                names.add(0, name);
            }
        }
    }
}