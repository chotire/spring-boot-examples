package sungshin;

/**
 * @author YongSang
 */
public enum Profiles {
    /**
     * 로컬
     */
    LOCAL(Constants.LOCAL),

    /**
     * 개발
     */
    DEVELOPMENT(Constants.DEVELOPMENT),

    /**
     * 운영
     */
    PRODUCTION(Constants.PRODUCTION);

    private final String name;

    private Profiles(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public static class Constants {
        public static final String LOCAL = "local";
        public static final String DEVELOPMENT = "development";
        public static final String PRODUCTION = "prodution";
    }
}