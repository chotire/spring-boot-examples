package sungshin.base.storage;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author YongSang
 */
public class DefaultSubpath implements Subpath {
    private String[] subpath;

    public DefaultSubpath(String... others) {
        subpath = others;
    }

    @Override
    public List<String> resolve() {
        return new ArrayList<String>(Arrays.asList(subpath));
    }
}