package sungshin.base.service;

import org.springframework.transaction.annotation.Transactional;

@Transactional
public class BaseService {
}