package sungshin.base.storage;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import sungshin.base.storage.model.FileBucket;

/**
 * @author YongSang
 */
@Service
@Transactional
public class FileSystemStorageService implements StorageService, InitializingBean {
    @Autowired
    private StorageMapper mapper;

    @Autowired
    private StorageProperties props;

    private String rootLocation;
    private List<String> allowedExtensions;

    @Override
    public List<FileBucket> store(String id, List<MultipartFile> multipartFiles, Subpath subpath) {
        if (!CollectionUtils.isEmpty(multipartFiles)) {
            List<FileBucket> fileBuckets = new ArrayList<FileBucket>(multipartFiles.size());
            if (StringUtils.isEmpty(id)) {
                id = RandomStringUtils.randomAlphanumeric(30);
            }

            for (MultipartFile multipartFile : multipartFiles) {
                if (multipartFile == null || multipartFile.isEmpty()) {
                    continue;
                }

                String extension = FilenameUtils.getExtension(multipartFile.getOriginalFilename());
                if (!allowedExtensions.contains(extension)) {
                    throw new StorageException("Not allowed file extension " + multipartFile.getOriginalFilename());
                }

                FileBucket fileBucket = new FileBucket();
                fileBucket.setId(id);
                fileBucket.setBackNumber(Integer.parseInt(RandomStringUtils.randomNumeric(7)));
                fileBucket.setChangedFilename(fileBucket.getId() + "-" + fileBucket.getBackNumber());
                fileBucket.setOriginalFilename(multipartFile.getOriginalFilename());
                fileBucket.setFileSize(multipartFile.getSize());

                List<String> partial = subpath.resolve();
                partial.add(fileBucket.getChangedFilename());
                Path path = Paths.get(rootLocation, partial.toArray(new String[partial.size()]));
                fileBucket.setLocation(path.getParent().toString());

                try {
                    Files.createDirectories(path.getParent());
                    Files.copy(multipartFile.getInputStream(), path);
                    fileBuckets.add(fileBucket);

                    mapper.insert(fileBucket);
                } catch (Exception e) {
                    for (FileBucket file : fileBuckets) {
                        Path filepath = Paths.get(file.getLocation(), file.getChangedFilename());
                        try {
                            Files.deleteIfExists(filepath);
                        } catch (IOException ioe) {
                            throw new StorageException(ioe);
                        }
                    }
                    throw new StorageException("Failed to store", e);
                }
            }
            return fileBuckets;
        }
        return Collections.emptyList();
    }

    @Override
    public FileBucket load(String id) {
        return mapper.findById(id);
    }

    @Override
    public FileBucket load(String id, Integer backNumber) {
        return mapper.findByPk(id, backNumber);
    }

    @Override
    public List<FileBucket> loadAll(String id) {
        return mapper.findAllById(id);
    }

    @Override
    public void remove(String id) {
        removeInternal(Arrays.asList(load(id)));
    }

    @Override
    public void remove(String id, List<Integer> backNumbers) {
        List<FileBucket> fileBuckets = mapper.findAllByIdAndBackNumberIn(id, backNumbers);
        removeInternal(fileBuckets);
    }

    @Override
    public void removeAll(String id) {
        removeInternal(loadAll(id));
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        this.rootLocation = props.getLocation();
        this.allowedExtensions = props.getAllowedExtensions();
    }

    private void removeInternal(List<FileBucket> fileBuckets) {
        for (FileBucket fileBucket : fileBuckets) {
            fileBucket.setDeleted(Boolean.TRUE);
            mapper.update(fileBucket);
        }
    }
}
