package sungshin.base.storage;

import java.util.List;

/**
 * @author YongSang
 */
public interface Subpath {
    List<String> resolve();
}