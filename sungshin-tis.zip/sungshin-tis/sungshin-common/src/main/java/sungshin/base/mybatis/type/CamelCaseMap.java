package sungshin.base.mybatis.type;

import java.util.HashMap;

import org.springframework.jdbc.support.JdbcUtils;

/**
 * @author YongSang
 */
@SuppressWarnings("serial")
public class CamelCaseMap extends HashMap<String, Object> {
    public CamelCaseMap() {
        super();
    }

    /**
     * Map의 put을 오버라이드해 key값을 camel 표기법으로 변환하여 put 한다.
     *
     * @see java.util.HashMap#put(java.lang.Object, java.lang.Object)
     */
    @Override
    public Object put(String key, Object value) {
        return super.put(JdbcUtils.convertUnderscoreNameToPropertyName(key), value);
    }

    public String getString(String key) {
        return get(key) != null ? get(key).toString() : null;
    }

    public int getInt(String key) {
        return get(key) != null ? Integer.parseInt(get(key).toString()) : 0;
    }

    public long getLong(String key) {
        return get(key) != null ? Long.parseLong(get(key).toString()) : 0;
    }

    public float getFloat(String key) {
        return get(key) != null ? Float.parseFloat(get(key).toString()) : 0f;
    }

    public double getDouble(String key) {
        return get(key) != null ? Double.parseDouble(get(key).toString()) : 0d;
    }
}