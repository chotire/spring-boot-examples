package sungshin.base.storage;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import sungshin.base.storage.model.FileBucket;

/**
 * @author YongSang
 */
@Repository
public interface StorageMapper {
    int insert(FileBucket fileBuckets);

    int update(FileBucket fileBucket);

    FileBucket findByPk(@Param("id") String id, @Param("backNumber") Integer backNumber);

    FileBucket findById(String id);

    List<FileBucket> findAllById(String id);

    List<FileBucket> findAllByIdAndBackNumberIn(@Param("id") String id, @Param("backNumbers") List<Integer> backNumbers);
}