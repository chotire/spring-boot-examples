package sungshin.base.storage;

/**
 * @author YongSang
 */
public class SubpathFactory {
    public static final String DATE_BASED_TYPE = "date";
    public static final String DEFAULT_TYPE = "default";

    public static Subpath create(String type, String[] others) {
        switch (type) {
            case DATE_BASED_TYPE:
                return new DateBasedSubpath(others);
            case DEFAULT_TYPE:
                return new DefaultSubpath(others);
            default:
                throw new UnsupportedOperationException("\"" + type + "\" is an unsupported type.");
        }
    }
}