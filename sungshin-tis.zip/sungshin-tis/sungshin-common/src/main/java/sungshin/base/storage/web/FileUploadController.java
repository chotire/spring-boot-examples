package sungshin.base.storage.web;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.nexacro.spring.data.NexacroResult;

import sungshin.base.storage.StorageService;
import sungshin.base.storage.SubpathFactory;
import sungshin.base.storage.model.FileBucket;

/**
 * @author YongSang
 */
@Controller
public class FileUploadController {
    @Autowired
    private StorageService service;

    @PostMapping("/files")
    public NexacroResult upload(HttpServletRequest request, @RequestParam(required = false) String id,
            @RequestParam(required = false, defaultValue = "date") String type, @RequestParam String[] others) {
        MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
        Map<String, MultipartFile> fileMap = multipartRequest.getFileMap();
        List<FileBucket> fileBuckets = service.store(id, new ArrayList<>(fileMap.values()), SubpathFactory.create(type, others));
        return new NexacroResult("files", fileBuckets);
    }

    @GetMapping("/files/{id}")
    public NexacroResult load(@PathVariable String id) {
        return new NexacroResult("file", service.load(id));
    }

    @GetMapping("/files/{id}/{backNumber}")
    public NexacroResult load(@PathVariable String id, @PathVariable Integer backNumber) {
        return new NexacroResult("file", service.load(id, backNumber));
    }

    @GetMapping("/files/{id}/all")
    public NexacroResult loadAll(@PathVariable String id) {
        return new NexacroResult("files", service.loadAll(id));
    }

    @DeleteMapping("/files/{id}")
    public NexacroResult delete(@PathVariable String id) {
        service.remove(id);
        return new NexacroResult();
    }

    @DeleteMapping("/files/{id}/{backNumbers}")
    public NexacroResult delete(@PathVariable String id, @PathVariable List<Integer> backNumbers) {
        service.remove(id, backNumbers);
        return new NexacroResult();
    }

    @DeleteMapping("/files/{id}/all")
    public NexacroResult deleteAll(@PathVariable String id) {
        service.removeAll(id);
        return new NexacroResult();
    }
}