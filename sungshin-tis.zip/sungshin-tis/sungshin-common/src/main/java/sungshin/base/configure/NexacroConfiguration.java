package sungshin.base.configure;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.nexacro.spring.context.ApplicationContextProvider;
import com.nexacro.spring.dao.DbVendorsProvider;
import com.nexacro.spring.dao.Dbms;
import com.nexacro.spring.dao.DbmsProvider;
import com.nexacro.spring.dao.dbms.Oracle;
import com.nexacro.spring.dao.mybatis.NexacroMybatisMetaDataProvider;
import com.nexacro.spring.dao.mybatis.NexacroMybatisResultSetHandler;
import com.nexacro.spring.resolve.NexacroHandlerMethodReturnValueHandler;
import com.nexacro.spring.resolve.NexacroMethodArgumentResolver;
import com.nexacro.spring.servlet.NexacroInterceptor;
import com.nexacro.spring.view.NexacroFileView;
import com.nexacro.spring.view.NexacroView;
import com.nexacro.xapi.tx.PlatformType;

/**
 * @author YongSang
 */
@Configuration
public class NexacroConfiguration extends WebMvcConfigurerAdapter {
    public NexacroConfiguration(SqlSessionFactory sqlSessionFactory) {
        sqlSessionFactory.getConfiguration().addInterceptor(new NexacroMybatisMetaDataProvider());
        sqlSessionFactory.getConfiguration().addInterceptor(new NexacroMybatisResultSetHandler());
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new NexacroInterceptor());
    }

    @Override
    public void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers) {
        argumentResolvers.add(new NexacroMethodArgumentResolver());
    }

    @Override
    public void addReturnValueHandlers(List<HandlerMethodReturnValueHandler> returnValueHandlers) {
        NexacroView nexacroView = new NexacroView();
        nexacroView.setDefaultContentType(PlatformType.CONTENT_TYPE_XML);
        nexacroView.setDefaultCharset(PlatformType.DEFAULT_CHAR_SET);

        NexacroHandlerMethodReturnValueHandler nexacroReturnValueHandler = new NexacroHandlerMethodReturnValueHandler();
        nexacroReturnValueHandler.setView(nexacroView);
        nexacroReturnValueHandler.setFileView(new NexacroFileView());

        returnValueHandlers.add(nexacroReturnValueHandler);
    }

    @Bean("dbmsProvider")
    public DbmsProvider dbmsProvider() {
        DbVendorsProvider provider = new DbVendorsProvider();
        Map<String, Dbms> vendors = new HashMap<>(1);
        vendors.put("Oracle", new Oracle());
        provider.setDbvendors(vendors);
        return provider;
    }

    @Bean
    public ApplicationContextProvider applicationContextProvider() {
        return new ApplicationContextProvider();
    }
}