package sungshin.base.storage.web;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.Charset;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import sungshin.base.storage.StorageProperties;
import sungshin.base.storage.StorageService;
import sungshin.base.storage.model.FileBucket;

/**
 * @author YongSang
 */
@Controller
public class FileDownloadController {
    public static final SimpleDateFormat DEFAULT_ZIP_NAME = new SimpleDateFormat("yyyyMMddHHmm");

    @Autowired
    private StorageService service;

    @Autowired
    private StorageProperties props;

    @GetMapping("/files/{id}/download")
    public ResponseEntity<Resource> download(@PathVariable String id) throws IOException {
        return downloadInternal(service.load(id));
    }

    @GetMapping("/files/{id}/{backNumber}/download")
    public ResponseEntity<Resource> download(@PathVariable String id, @PathVariable Integer backNumber) throws IOException {
        return downloadInternal(service.load(id, backNumber));
    }

    @GetMapping("/files/{id}/download/all")
    public ResponseEntity<Resource> downloadAll(@PathVariable String id, @RequestParam(required=false) String filename) throws IOException, URISyntaxException {
        return downloadInternal(service.loadAll(id), StringUtils.isEmpty(filename) ? DEFAULT_ZIP_NAME.format(new Date()) : filename);
    }

    private ResponseEntity<Resource> downloadInternal(FileBucket fileBucket) throws IOException {
        if (fileBucket == null) {
            return null;
        }
        Path path = Paths.get(fileBucket.getLocation(), fileBucket.getChangedFilename());
        Resource resource = new ByteArrayResource(Files.readAllBytes(path));

        HttpHeaders headers = new HttpHeaders();
        headers.setContentDispositionFormData("attachment", fileBucket.getOriginalFilename(), Charset.forName("utf-8"));

        return ResponseEntity.ok()
                .headers(headers)
                .contentLength(fileBucket.getFileSize())
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(resource);
    }

    private ResponseEntity<Resource> downloadInternal(List<FileBucket> fileBuckets, String filename) throws IOException, URISyntaxException {
        Path path = Paths.get(props.getTempLocation(), RandomStringUtils.randomAlphanumeric(30) + ".zip");
        Files.createDirectories(path.getParent());

        Map<String, String> zipProps = new HashMap<>();
        zipProps.put("create", Boolean.toString(true));
        zipProps.put("encoding", Charset.forName("utf-8").displayName());
        URI zipFile = URI.create("jar:" + path.toUri());

        try (FileSystem zipfs = FileSystems.newFileSystem(zipFile, zipProps)) {
            for (FileBucket fileBucket : fileBuckets) {
                Path externalFile = Paths.get(fileBucket.getLocation(), fileBucket.getChangedFilename());
                Path pathInZipfile = zipfs.getPath(fileBucket.getOriginalFilename());
                Files.copy(externalFile, pathInZipfile, StandardCopyOption.REPLACE_EXISTING );
            }
        }

        if (filename.lastIndexOf(".zip") == -1) {
            filename = filename + ".zip";
        }
        Resource resource = new ByteArrayResource(Files.readAllBytes(path));
        HttpHeaders headers = new HttpHeaders();
        headers.setContentDispositionFormData("attachment", filename, Charset.forName("utf-8"));

        return ResponseEntity.ok()
                .headers(headers)
                .contentLength(path.toFile().length())
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(resource);
    }
}