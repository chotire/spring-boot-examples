package sungshin.base.storage;

import java.nio.file.Paths;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

/**
 * @author YongSang
 */
@Data
@Component
@ConfigurationProperties(prefix="sungshin.file.storage", ignoreUnknownFields=false)
public class StorageProperties {
    /**
     * 첨부파일 저장 루트 경로
     */
    private String location = Paths.get(System.getProperty("user.home")).toString();

    /**
     * 압축파일 생성 임시 저장 경로
     */
    private String tempLocation = Paths.get(location, "temp").toString();

    /**
     * 업로드 허용 확장자 리스트
     */
    private List<String> allowedExtensions;
}