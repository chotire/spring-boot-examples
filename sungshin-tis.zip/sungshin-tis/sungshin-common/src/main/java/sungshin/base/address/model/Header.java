package sungshin.base.address.model;

import lombok.Data;

/**
 * @author YongSang
 */
@Data
public class Header {
    private String totalCount;
    private int currentPage;
    private int countPerPage;
    private String errorCode;
    private String errorMessage;
}