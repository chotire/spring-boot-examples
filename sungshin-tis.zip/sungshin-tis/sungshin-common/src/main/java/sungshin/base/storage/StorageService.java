package sungshin.base.storage;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import sungshin.base.storage.model.FileBucket;

/**
 * @author YongSang
 */
public interface StorageService {
    List<FileBucket> store(String id, List<MultipartFile> multipartFiles, Subpath subpath);

    FileBucket load(String id);

    FileBucket load(String id, Integer backNumber);

    List<FileBucket> loadAll(String id);

    void remove(String id);

    void remove(String id, List<Integer> backNumbers);

    void removeAll(String id);
}