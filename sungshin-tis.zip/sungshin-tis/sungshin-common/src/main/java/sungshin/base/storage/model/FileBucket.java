package sungshin.base.storage.model;

import java.util.Date;

import com.nexacro.spring.annotation.DataSetIgnore;

import lombok.Data;
import lombok.Getter;
import sungshin.base.domain.Domain;

/**
 * @author YongSang
 */
@Data
public class FileBucket extends Domain {
    private String id;

    private Integer backNumber;

    private String originalFilename;

    @Getter(onMethod=@__({@DataSetIgnore}))
    private String changedFilename;

    @Getter(onMethod=@__({@DataSetIgnore}))
    private String location;

    private Long fileSize = 0L;

    @Getter(onMethod=@__({@DataSetIgnore}))
    private Boolean deleted = Boolean.FALSE;

    @Getter(onMethod=@__({@DataSetIgnore}))
    private Date timestamp = new Date();
}