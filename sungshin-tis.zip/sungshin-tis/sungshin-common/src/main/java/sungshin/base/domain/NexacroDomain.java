package sungshin.base.domain;

import com.nexacro.spring.data.DataSetRowTypeAccessor;
import com.nexacro.xapi.data.DataSet;

import lombok.Data;

/**
 * @author YongSang
 */
@Data
public class NexacroDomain extends Domain implements DataSetRowTypeAccessor {
    /**
     * DataSet의 RowType은 nexacro platform에서 transaction 시 입력 데이터셋의
     * 전송옵션이 :U 혹은 :A 일때 행의 타입을 확인할 수 있다.
     * :N 옵션일 경우에는 Normal 상태이다. (default)
     */
    private int rowType = DataSet.ROW_TYPE_NORMAL;

    @Override
    public int getRowType() {
        return this.rowType;
    }

    @Override
    public void setRowType(int rowType) {
        this.rowType = rowType;
    }
}