package sungshin.base.address.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * @author YongSang
 */
@Data
public class ZipCode {
    @JsonProperty("common")
    private Header header;
    @JsonProperty("juso")
    private List<Address> addresses;
}