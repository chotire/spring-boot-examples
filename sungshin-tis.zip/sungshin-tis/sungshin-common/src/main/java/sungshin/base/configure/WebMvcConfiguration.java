package sungshin.base.configure;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpMethod;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.i18n.CookieLocaleResolver;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;

import sungshin.Profiles;

/**
 * @author YongSang
 */
@Configuration
public class WebMvcConfiguration extends WebMvcConfigurerAdapter {
    @Configuration
    public static class I18nConfiguration extends WebMvcConfigurerAdapter {
        @Bean
        public LocaleResolver localeResolver() {
            CookieLocaleResolver localeResolver = new CookieLocaleResolver();
            localeResolver.setCookieName("locale");
            return localeResolver;
        }

        @Override
        public void addInterceptors(InterceptorRegistry registry) {
            LocaleChangeInterceptor localeChangeInterceptor = new LocaleChangeInterceptor();
            localeChangeInterceptor.setParamName("lang");
            registry.addInterceptor(localeChangeInterceptor);
        }
    }

    @Configuration
    public static class CorsConfiguration {
        @Bean
        @Profile(Profiles.Constants.LOCAL)
        public WebMvcConfigurer localCorsConfigurer() {
            return new WebMvcConfigurerAdapter() {
                @Override
                public void addCorsMappings(CorsRegistry registry) {
                    String[] allowedMethods = new String[HttpMethod.values().length];
                    HttpMethod[] httpMethods = HttpMethod.values();
                    for (int i = 0; i < httpMethods.length; i++) {
                        allowedMethods[i] = httpMethods[i].name();
                    }
                    registry.addMapping("/**").allowedOrigins("*").allowedMethods(allowedMethods);
                }
            };
        }

        /**
         * 개발, 운영의 경우에는 향후 결정될 도메인에 따라 적용하도록 한다.
         * allowedOrigins의 값을 '*'로 하면 절대 안되며(보안상 너무 취약해짐)
         * 반드시 적절한 도메인을 넣도록 한다.
         * @return
         */
        @Bean
        @Profile(value = {Profiles.Constants.DEVELOPMENT, Profiles.Constants.PRODUCTION})
        public WebMvcConfigurer nonlocalCorsConfigurer() {
            return new WebMvcConfigurerAdapter() {
                @Override
                public void addCorsMappings(CorsRegistry registry) {
                }
            };
        }
    }
}