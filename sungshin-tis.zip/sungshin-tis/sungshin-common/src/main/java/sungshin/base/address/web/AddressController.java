package sungshin.base.address.web;

import java.io.IOException;
import java.net.URI;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.nexacro.spring.data.NexacroResult;

import sungshin.base.address.model.ZipCode;

/**
 * 향후 URL(@GetMapping 부분) 및 데이터소스 이름은
 * 프로젝트 표준에 맞게 수정
 *
 * @author YongSang
 */
@Controller
public class AddressController {
    public static final String API_URL = "http://www.juso.go.kr/addrlink/addrLinkApi.do";

    @GetMapping("/addresses/{keyword}")
    public NexacroResult findByKeyword(@PathVariable String keyword) throws IOException {
        URI uri = UriComponentsBuilder.fromUriString(API_URL)
                .queryParam("currentPage", 1)
                .queryParam("countPerPage", 10)
                .queryParam("resultType", "json")
                .queryParam("confmKey", "U01TX0FVVEgyMDE2MTEyODEzNTkzNjE2ODY1")
                .queryParam("keyword", keyword)
                .build()
                .encode("utf-8")
                .toUri();

        RestTemplate restTemplate = new RestTemplate();
        String responseText = restTemplate.getForObject(uri, String.class);

        ObjectMapper mapper = new ObjectMapper();
        ObjectReader reader = mapper.readerFor(ZipCode.class).withRootName("results");
        ZipCode zipCode = reader.readValue(responseText);

        NexacroResult result = new NexacroResult();
        result.addDataSet("header", zipCode.getHeader());
        result.addDataSet("addresses", zipCode.getAddresses());
        return result;
    }
}