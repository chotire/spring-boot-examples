package sungshin.base.address.model;

import lombok.Data;

/**
 * @author YongSang
 */
@Data
public class Address {
    private String roadAddr;
    private String roadAddrPart1;
    private String roadAddrPart2;
    private String jibunAddr;
    private String engAddr;
    private String zipNo;
    private String admCd;
    private String rnMgtSn;
    private String bdMgtSn;
    private String detBdNmList;
}