package sungshin.base.storage;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.lang.ArrayUtils;

/**
 * @author YongSang
 */
public class DateBasedSubpath implements Subpath {
    private boolean y;
    private boolean m;
    private boolean d;
    private List<String> initPath;

    public DateBasedSubpath(String... others) {
        this(true, true, false, others);
    }

    public DateBasedSubpath(boolean y) {
        this(y, false, false, ArrayUtils.EMPTY_STRING_ARRAY);
    }

    public DateBasedSubpath(boolean y, boolean m) {
        this(y, m, false, ArrayUtils.EMPTY_STRING_ARRAY);
    }

    public DateBasedSubpath(boolean y, boolean m, boolean d) {
        this(y, m, d, ArrayUtils.EMPTY_STRING_ARRAY);
    }

    public DateBasedSubpath(boolean y, boolean m, boolean d, String... others) {
        this.y = y;
        this.m = m;
        this.d = d;
        initPath = new ArrayList<String>(Arrays.asList(others));
    }

    @Override
    public List<String> resolve() {
        List<String> subpath = new ArrayList<String>(initPath);
        Calendar now = Calendar.getInstance();
        if (y) {
            subpath.add(String.valueOf(now.get(Calendar.YEAR)));
        }
        if (m) {
            subpath.add(String.valueOf(now.get(Calendar.MONTH) + 1));
        }
        if (d) {
            subpath.add(String.valueOf(now.get(Calendar.DAY_OF_MONTH)));
        }
        return subpath;
    }
}