package sungshin.base.domain;

import java.util.Date;

import lombok.Data;

/**
 * @author YongSang
 */
@Data
public class Domain {
    /** 입력사용자ID */
    private String inpUserId;
    /** 입력사용자프로그램ID */
    private String inpUserPgmId;
    /** 입력사용자입력일시 */
    private Date inpUserInpDm;
    /** 입력사용자입력IP주소 */
    private String inpUserInpIpAddr;
    /** 변경사용자ID */
    private String chgUserId;
    /** 변경사용자프로그램ID */
    private String chgUserPgmId;
    /** 변경사용자수정일시 */
    private Date chgUserUpdDm;
    /** 변경사용자IP주소 */
    private String chgUserIpAddr;

    public Domain() {
        initLoginData();
    }

    private void initLoginData(){
        this.inpUserId = "SYSTEM";
        this.inpUserPgmId = "SYSTEMPGM";
        this.inpUserInpDm = getSysdate();
        this.inpUserInpIpAddr = "127.0.0.1";

        this.chgUserId = "SYSTEM";
        this.inpUserPgmId = "SYSTEMPGM";
        this.chgUserUpdDm = getSysdate();
        this.chgUserIpAddr = "127.0.0.1";
    }

    public Date getSysdate(){
        return new Date();
    }
}