package sungshin.base.batch;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.time.DateUtils;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration("removeSpringBatchHistoryJobConfiguration")
public class RemoveSpringBatchHistoryJob extends BatchJob {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Bean
    public Job removeSpringBatchHistoryJob() {
        return jobs.get("removeSpringBatchHistoryJob")
                .start(removeSpringBatchHistoryStep())
                .build();
    }

    @Bean
    public Step removeSpringBatchHistoryStep() {
        return steps.get("removeSpringBatchHistoryStep")
                .tasklet(removeSpringBatchHistoryTasklet())
                .allowStartIfComplete(true)
                .build();
    }

    @Bean
    public Tasklet removeSpringBatchHistoryTasklet() {
        return new Tasklet() {
            private static final String SQL_DELETE_BATCH_STEP_EXECUTION_CONTEXT = "DELETE FROM BATCH_STEP_EXECUTION_CONTEXT WHERE STEP_EXECUTION_ID IN (SELECT STEP_EXECUTION_ID FROM BATCH_STEP_EXECUTION WHERE JOB_EXECUTION_ID IN (SELECT JOB_EXECUTION_ID FROM  BATCH_JOB_EXECUTION where CREATE_TIME < ?))";
            private static final String SQL_DELETE_BATCH_STEP_EXECUTION = "DELETE FROM BATCH_STEP_EXECUTION WHERE JOB_EXECUTION_ID IN (SELECT JOB_EXECUTION_ID FROM BATCH_JOB_EXECUTION where CREATE_TIME < ?)";
            private static final String SQL_DELETE_BATCH_JOB_EXECUTION_CONTEXT = "DELETE FROM BATCH_JOB_EXECUTION_CONTEXT WHERE JOB_EXECUTION_ID IN (SELECT JOB_EXECUTION_ID FROM  BATCH_JOB_EXECUTION where CREATE_TIME < ?)";
            private static final String SQL_DELETE_BATCH_JOB_EXECUTION_PARAMS = "DELETE FROM BATCH_JOB_EXECUTION_PARAMS WHERE JOB_EXECUTION_ID IN (SELECT JOB_EXECUTION_ID FROM BATCH_JOB_EXECUTION where CREATE_TIME < ?)";
            private static final String SQL_DELETE_BATCH_JOB_EXECUTION = "DELETE FROM BATCH_JOB_EXECUTION where CREATE_TIME < ?";
            private static final String SQL_DELETE_BATCH_JOB_INSTANCE = "DELETE FROM BATCH_JOB_INSTANCE WHERE JOB_INSTANCE_ID NOT IN (SELECT JOB_INSTANCE_ID FROM BATCH_JOB_EXECUTION)";

            private Integer historicRetentionDay = 15;

            @Override
            public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {
                int totalCount = 0;
                Date date = DateUtils.addDays(new Date(), -historicRetentionDay);
                DateFormat df = new SimpleDateFormat();
                log.info("Remove the Spring Batch history before the {}", df.format(date));

                int rowCount = jdbcTemplate.update(SQL_DELETE_BATCH_STEP_EXECUTION_CONTEXT, date);
                log.info("Deleted rows number from the BATCH_STEP_EXECUTION_CONTEXT table: {}", rowCount);
                totalCount += rowCount;

                rowCount = jdbcTemplate.update(SQL_DELETE_BATCH_STEP_EXECUTION, date);
                log.info("Deleted rows number from the BATCH_STEP_EXECUTION table: {}", rowCount);
                totalCount += rowCount;

                rowCount = jdbcTemplate.update(SQL_DELETE_BATCH_JOB_EXECUTION_CONTEXT, date);
                log.info("Deleted rows number from the BATCH_JOB_EXECUTION_CONTEXT table: {}", rowCount);
                totalCount += rowCount;

                rowCount = jdbcTemplate.update(SQL_DELETE_BATCH_JOB_EXECUTION_PARAMS, date);
                log.info("Deleted rows number from the BATCH_JOB_EXECUTION_PARAMS table: {}", rowCount);
                totalCount += rowCount;

                rowCount = jdbcTemplate.update(SQL_DELETE_BATCH_JOB_EXECUTION, date);
                log.info("Deleted rows number from the BATCH_JOB_EXECUTION table: {}", rowCount);
                totalCount += rowCount;

                rowCount = jdbcTemplate.update(SQL_DELETE_BATCH_JOB_INSTANCE);
                log.info("Deleted rows number from the BATCH_JOB_INSTANCE table: {}", rowCount);
                totalCount += rowCount;

                contribution.incrementWriteCount(totalCount);

                return RepeatStatus.FINISHED;
            }
        };
    }

    @Component
    public static class RemoveSpringBatchHistoryJobScheduler {
        private JobLauncher launcher;
        private Job removeSpringBatchHistoryJob;

        @Autowired
        public RemoveSpringBatchHistoryJobScheduler(JobLauncher launcher, @Qualifier("removeSpringBatchHistoryJob") Job removeSpringBatchHistoryJob) {
            this.launcher = launcher;
            this.removeSpringBatchHistoryJob = removeSpringBatchHistoryJob;
        }

        @Scheduled(cron="0 59 16 * * *")
        public void run() throws Exception {
            launcher.run(removeSpringBatchHistoryJob, new JobParameters());
        }
    }
}