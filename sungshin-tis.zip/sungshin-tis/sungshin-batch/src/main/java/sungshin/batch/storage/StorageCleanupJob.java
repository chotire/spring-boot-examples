package sungshin.batch.storage;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.mybatis.spring.batch.MyBatisBatchItemWriter;
import org.mybatis.spring.batch.MyBatisPagingItemReader;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;
import sungshin.base.batch.BatchJob;
import sungshin.base.storage.model.FileBucket;

/**
 * @author YongSang
 */
@Slf4j
@Configuration("storageCleanupJobConfiguration")
public class StorageCleanupJob extends BatchJob {
    @Bean
    public Job storageCleanupJob() {
        return jobs.get("storageCleanupJob")
                .start(storageCleanupStep())
                .build();
    }

    @Bean
    public Step storageCleanupStep() {
        return steps.get("storageCleanupStep")
                .<FileBucket, FileBucket> chunk(100)
                .reader(storageCleanupItemReader())
                .processor(storageCleanupProcessor())
                .writer(storageCleanupItemWriter())
                .allowStartIfComplete(true)
                .build();
    }

    @Bean
    public ItemReader<FileBucket> storageCleanupItemReader() {
        Calendar cal = Calendar.getInstance(Locale.KOREA);
        cal.add(Calendar.DAY_OF_YEAR, -3);

        Map<String, Object> parameterValues = new HashMap<>();
        parameterValues.put("deleted", Boolean.TRUE);
        parameterValues.put("timestamp", cal.getTime());

        MyBatisPagingItemReader<FileBucket> reader = new MyBatisPagingItemReader<>();
        reader.setSqlSessionFactory(sqlSession);
        reader.setQueryId("sungshin.batch.storage.StorageCleanupMapper.findAllByDeletedAndTimestamp");
        reader.setParameterValues(parameterValues);
        reader.setPageSize(100);
        return reader;
    }

    @Bean
    public ItemProcessor<FileBucket, FileBucket> storageCleanupProcessor() {
        return new ItemProcessor<FileBucket, FileBucket>() {
            @Override
            public FileBucket process(FileBucket fileBucket) throws Exception {
                Path path = Paths.get(fileBucket.getLocation(), fileBucket.getChangedFilename());
                Files.deleteIfExists(path);
                log.info("The file '{}' has been deleted.", path);
                return fileBucket;
            }
        };
    }

    @Bean
    public ItemWriter<FileBucket> storageCleanupItemWriter() {
        MyBatisBatchItemWriter<FileBucket> writer = new MyBatisBatchItemWriter<>();
        writer.setSqlSessionFactory(sqlSession);
        writer.setStatementId("sungshin.batch.storage.StorageCleanupMapper.delete");
        return writer;
    }

    @Component
    public static class StorageCleanupJobScheduler {
        private JobLauncher launcher;
        private Job storageCleanupJob;

        @Autowired
        public StorageCleanupJobScheduler(JobLauncher launcher, @Qualifier("storageCleanupJob") Job storageCleanupJob) {
            this.launcher = launcher;
            this.storageCleanupJob = storageCleanupJob;
        }

        @Scheduled(cron="0 0 3 * * *")
        public void run() throws Exception {
            launcher.run(storageCleanupJob, new JobParameters());
        }
    }
}