package sungshin.batch.storage;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;

import org.apache.commons.lang.time.DurationFormatUtils;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;
import sungshin.base.batch.BatchJob;
import sungshin.base.storage.StorageProperties;

/**
 * @author YongSang
 */
@Slf4j
@Configuration("temporaryStorageCleanupJobConfiguration")
public class TemporaryStorageCleanupJob extends BatchJob {
    @Autowired
    protected StorageProperties props;

    @Bean
    public Job temporaryStorageCleanupJob() {
        return jobs.get("temporaryStorageCleanupJob")
                .start(temporaryStorageCleanupStep())
                .build();
    }

    @Bean
    public Step temporaryStorageCleanupStep() {
        return steps.get("temporaryStorageCleanupStep")
                .tasklet(temporaryStorageCleanupTasklet())
                .allowStartIfComplete(true)
                .build();
    }

    @Bean
    public Tasklet temporaryStorageCleanupTasklet() {
        return new Tasklet() {
            final int period = 24;
            final Path dir = Paths.get(props.getTempLocation());

            @Override
            public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
                log.info("Starts deleting temporary files from this path. {}", dir);
                DirectoryStream<Path> stream = Files.newDirectoryStream(dir, new DirectoryStream.Filter<Path>() {
                    private Date now = new Date();

                    @Override
                    public boolean accept(Path entry) throws IOException {
                        int deletePeriod = Integer.parseInt(DurationFormatUtils.formatPeriod(
                                Files.getLastModifiedTime(entry).toMillis(), now.getTime(), "HH"));
                        return deletePeriod > period;
                    }
                });

                int count = 0;
                for (Path entry : stream) {
                    log.info("The file '{}' has been deleted.", entry);
                    Files.deleteIfExists(entry);
                    count++;
                }
                log.info("All {} files have been deleted.", count);
                return RepeatStatus.FINISHED;
            }
        };
    }

    @Component
    public static class TemporaryStorageCleanupJobScheduler {
        private JobLauncher launcher;
        private Job temporaryStorageCleanupJob;

        @Autowired
        public TemporaryStorageCleanupJobScheduler(JobLauncher launcher, @Qualifier("temporaryStorageCleanupJob") Job temporaryStorageCleanupJob) {
            this.launcher = launcher;
            this.temporaryStorageCleanupJob = temporaryStorageCleanupJob;
        }

        @Scheduled(cron="0 30 2 * * *")
        public void run() throws Exception {
            launcher.run(temporaryStorageCleanupJob, new JobParameters());
        }
    }
}